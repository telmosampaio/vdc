﻿
Configuration FormatDisk {
    param
    #v1.4
    (
        [Parameter(Mandatory)]
        [string]$DataDisks
        
    )

    Import-DscResource -ModuleName xStorage
    
    Node localhost
    {
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }

        $dataDisksJson = ConvertFrom-Json $DataDisks

        $dataDisksJson | ForEach-Object {

            $diskStatus = Get-Disk -Number $_.diskId -ErrorAction SilentlyContinue;
            # Null disk status means that the disk hasn't been initialized
            if ($null -eq $diskStatus) {
                xWaitforDisk $_.diskId
                {
                    DiskId =  $_.diskId
                    RetryIntervalSec = 60
                    RetryCount = 60
                }

                $dependency = '[xWaitForDisk]' + $_.diskId
        
                xDisk $_.driveLetter
                {
                    DiskId = $_.diskId
                    DriveLetter = $_.driveLetter
                    FSLabel = 'Data'
                    FSFormat = 'NTFS'
                    DependsOn = $dependency
                }
            }
        }
   }
}